#!/usr/bin/env python3
"""
Build next_nets.json for the next WINDOW_DAYS (default 7).

Reads from <BHN_REPO_ROOT>/_data:
  - nets.yml               (source of truth; uses rrule like FREQ=WEEKLY;BYDAY=SA)
  - ncos.yml               (optional; rota lists and/or current mappings)
  - nco_overrides.yml      (optional; per-date overrides: {YYYY-MM-DD: {net_id: CALL}})
  - vacations.yml          (optional; {CALL: [YYYY-MM-DD, ...]})

Outputs JSON to STDOUT; your shell publisher pretty-prints & installs it.

Env (via /opt/bhn/bhn.env):
  BHN_REPO_ROOT   -> repo root containing _data/      (default: $HOME)
  BHN_LOCAL_TZ    -> site/default tz (IANA)           (default: America/New_York)
  BHN_WINDOW_DAYS -> horizon in days                  (default: 7)
"""

from __future__ import annotations
import os, sys, json
from pathlib import Path
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
from zoneinfo import ZoneInfo

# --- Python 3.11+ has datetime.UTC; support older too
try:
    from datetime import UTC
except Exception:  # Py<3.11
    from datetime import timezone as _tz
    UTC = _tz.utc  # type: ignore

try:
    import yaml  # PyYAML
except Exception as e:
    sys.stderr.write(f"[error] PyYAML not installed: {e}\n")
    sys.exit(2)

# -------- Config --------
REPO_ROOT = Path(os.environ.get("BHN_REPO_ROOT", str(Path.home()))).resolve()
DATA_DIR = REPO_ROOT / "_data"
NETS_YAML       = DATA_DIR / "nets.yml"
ROTAS_YAML      = DATA_DIR / "ncos.yml"
OVERRIDES_YAML  = DATA_DIR / "nco_overrides.yml"
VACATIONS_YAML  = DATA_DIR / "vacations.yml"

LOCAL_TZ_NAME = os.environ.get("BHN_LOCAL_TZ", "America/New_York")
DEFAULT_TZ = ZoneInfo(LOCAL_TZ_NAME)
WINDOW_DAYS = int(os.environ.get("BHN_WINDOW_DAYS", "7"))

# -------- Helpers --------
DOW_ABBR = ["MO","TU","WE","TH","FR","SA","SU"]
DOW_MAP = {  # convenience for legacy "days:" fields
    "MON":0,"TUE":1,"WED":2,"THU":3,"FRI":4,"SAT":5,"SUN":6,
    "MONDAY":0,"TUESDAY":1,"WEDNESDAY":2,"THURSDAY":3,"FRIDAY":4,"SATURDAY":5,"SUNDAY":6
}

def load_yaml(path: Path):
    if not path.exists():
        return None
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def norm_days(obj) -> List[int]:
    if obj is None: return []
    vals = [obj] if isinstance(obj, str) else list(obj)
    out=[]
    for v in vals:
        if not v: continue
        k = str(v).strip().upper()
        if k in DOW_MAP: out.append(DOW_MAP[k])
    return sorted(set(out))

def norm_time_24h(s: str) -> Optional[str]:
    """Return 'HH:MM' or None. Accepts 24h and common 12h forms (+ strips trailing tz hints like 'ET')."""
    if not s:
        return None
    s = s.strip().upper()
    # strip trailing tz hints
    for tz_hint in (" ET"," EST"," EDT"," CT"," CST"," CDT"," MT"," MST"," MDT"," PT"," PST"," PDT"):
        if s.endswith(tz_hint):
            s = s[: -len(tz_hint)]
            break
    # already 24h?
    if ":" in s and ("AM" not in s) and ("PM" not in s):
        try:
            hh, mm = s.split(":", 1)
            return f"{int(hh):02d}:{int(mm[:2]):02d}"
        except Exception:
            pass
    # 12h parses
    from datetime import datetime as _dt
    for fmt in ("%I:%M %p", "%I %p", "%I.%M %p", "%I%p"):
        try:
            t = _dt.strptime(s, fmt)
            return t.strftime("%H:%M")
        except Exception:
            continue
    return None

def pick_tz(net: Dict[str,Any]) -> ZoneInfo:
    tzname = net.get("tz") or net.get("timezone") or net.get("time_zone") or LOCAL_TZ_NAME
    try:
        return ZoneInfo(str(tzname))
    except Exception:
        return DEFAULT_TZ

def build_iso(date_local_midnight: datetime, time_hm: str, duration_min: int, tz: ZoneInfo) -> Tuple[str,str,str,str]:
    # date_local_midnight: datetime at 00:00 in DEFAULT_TZ
    hh, mm = time_hm.split(":")
    start_local = date_local_midnight.astimezone(tz).replace(
        hour=int(hh), minute=int(mm), second=0, microsecond=0, tzinfo=tz
    )
    end_local = start_local + timedelta(minutes=int(duration_min or 0))
    return (start_local.isoformat(), end_local.isoformat(),
            start_local.strftime("%Y-%m-%d"), start_local.strftime("%H:%M"))

def norm_call(s: Optional[str]) -> str:
    return (s or "").strip().upper()

# --- RRULE helpers (minimal WEEKLY and MONTHLY with BYDAY/BYSETPOS) ---
def parse_rrule(rr: str) -> dict:
    """Parse simple RFC5545-ish string into dict: {'FREQ':'WEEKLY','BYDAY':['SA'],'BYSETPOS':'1'}"""
    if not rr:
        return {}
    out = {}
    for part in str(rr).split(";"):
        if not part or "=" not in part:
            continue
        k, v = part.split("=", 1)
        out[k.strip().upper()] = v.strip().upper()
    if "BYDAY" in out:
        out["BYDAY"] = [d.strip().upper() for d in out["BYDAY"].split(",") if d.strip()]
    return out

def monthly_matches(date_obj, byday_list, bysetpos):
    """True if date_obj is the Nth weekday of the month (supports n=1..5 or -1 for last)."""
    import calendar
    y, m = date_obj.year, date_obj.month
    wanted = set(DOW_ABBR.index(d) for d in byday_list if d in DOW_ABBR)
    c = calendar.Calendar(firstweekday=calendar.MONDAY)
    matches = [d for d in c.itermonthdates(y, m) if d.month == m and d.weekday() in wanted]
    if not matches:
        return False
    try:
        n = int(bysetpos)
    except Exception:
        return False
    if n == -1:
        return date_obj == matches[-1]
    if 1 <= n <= len(matches):
        return date_obj == matches[n-1]
    return False

def occurs_on(date_obj, rrule_dict) -> bool:
    """True if date_obj matches the (WEEKLY or MONTHLY) rule."""
    if not rrule_dict or "FREQ" not in rrule_dict:
        return False
    freq = rrule_dict["FREQ"].upper()
    byday = rrule_dict.get("BYDAY", [])
    if freq == "WEEKLY":
        if not byday:
            return False
        wanted = set(DOW_ABBR.index(d) for d in byday if d in DOW_ABBR)
        return date_obj.weekday() in wanted
    if freq == "MONTHLY":
        if not byday:
            return False
        bysetpos = rrule_dict.get("BYSETPOS", "1")
        return monthly_matches(date_obj, byday, bysetpos)
    return False  # other FREQ types not implemented here

# --- NCO selection ---
def nco_for(net_id: str, date_str: str, rota_idx: Dict[str,List[str]],
            overrides: Dict[str,Any], vacations_idx: Dict[str,set]) -> Tuple[str,bool,str]:
    """
    Return (nco, unassigned, source)
    Priority: override > rota (with vacation skip) > unassigned
    """
    # overrides: { "YYYY-MM-DD": { "<net_id>": "CALL" } }
    ov = overrides.get(date_str) or {}
    if isinstance(ov, dict):
        nco = norm_call(ov.get(net_id))
        if nco:
            return (nco, False, "override")

    rota = [norm_call(c) for c in (rota_idx.get(net_id) or []) if c]
    if rota:
        # Weekly rotation by ISO week number (simple and predictable)
        try:
            y,m,d = map(int, date_str.split("-"))
            week = datetime(y,m,d).isocalendar().week
        except Exception:
            week = 0
        base = rota[week % len(rota)]
        cand = base
        if date_str in vacations_idx.get(cand, set()):
            try:
                i = rota.index(cand)
                for j in range(1, len(rota)+1):
                    nxt = rota[(i+j) % len(rota)]
                    if date_str not in vacations_idx.get(nxt, set()):
                        cand = nxt; break
            except ValueError:
                pass
        return (cand, False, "rota" if cand==base else "rota (vacation-skip)")

    # Fallback to current map (if provided in ncos.yml)
    # e.g., ncos.yml: { current: { "<net_id>": "CALL" } }
    nco_current = (rota_idx.get("__current__map__") or {}).get(net_id)
    if nco_current:
        return (norm_call(nco_current), False, "current-map")

    return ("", True, "unassigned")

def build_rota_index(ncos: Dict[str,Any]) -> Dict[str,Any]:
    """Support either {rotation: {net_id: [calls...]}} or flat {net_id: [calls...]}, plus optional {current:{...}}."""
    if not isinstance(ncos, dict):
        return {}
    out: Dict[str,Any] = {}
    # explicit rotations
    if isinstance(ncos.get("rotation"), dict):
        for nid, seq in (ncos.get("rotation") or {}).items():
            if isinstance(seq, list):
                out[str(nid)] = [norm_call(x) for x in seq]
    # flat form
    for k, v in ncos.items():
        if k in ("rotation","overrides","current","time_zone","start_local","duration_min","location"):
            continue
        if isinstance(v, list) and all(isinstance(x, (str, int)) for x in v):
            out[str(k)] = [norm_call(x) for x in v]
    # current map kept in a special slot
    if isinstance(ncos.get("current"), dict):
        out["__current__map__"] = {str(k): norm_call(v) for k, v in ncos.get("current", {}).items()}
    return out

# -------- Main --------
def main() -> int:
    nets_data = load_yaml(NETS_YAML) or {}
    nets = nets_data.get("nets") if isinstance(nets_data, dict) else nets_data
    if not isinstance(nets, list):
        nets = []

    ncos = load_yaml(ROTAS_YAML) or {}
    overrides = load_yaml(OVERRIDES_YAML) or {}
    vacations = load_yaml(VACATIONS_YAML) or {}
    vacations_idx = { norm_call(k): set(v or []) for k, v in (vacations or {}).items() }
    rota_idx = build_rota_index(ncos)

    now_default = datetime.now(DEFAULT_TZ)
    window_end = now_default + timedelta(days=WINDOW_DAYS)
    today = now_default.date()
    day0 = datetime.combine(today, datetime.min.time()).replace(tzinfo=DEFAULT_TZ)

    occurrences: List[Dict[str,Any]] = []

    for net in nets:
        if not isinstance(net, dict):
            continue

        # ---- tolerant extraction ----
        name = (net.get("name") or net.get("title") or "").strip()
        net_id = (net.get("id") or net.get("net_id") or "").strip()
        if not net_id and name:
            net_id = "".join(ch.lower() if ch.isalnum() else "-" for ch in name).strip("-")
        if not net_id or not name:
            continue

        # time components
        raw_time = (
            net.get("start_local") or net.get("time") or net.get("start") or
            net.get("when") or net.get("time_local") or ""
        )
        t24 = norm_time_24h(raw_time) or "10:00"

        duration = int(net.get("duration_min") or net.get("duration") or net.get("length_min") or 60)
        tz = pick_tz(net)

        location = (
            net.get("location") or net.get("where") or net.get("links") or ""
        ).strip()

        # recurrence: explicit days[] OR rrule
        days_idx = norm_days(
            net.get("days") or net.get("dow") or net.get("day") or
            net.get("weekday") or net.get("weekdays")
        )
        rrule_raw = (net.get("rrule") or "").strip()
        rrule_dict = parse_rrule(rrule_raw)

        # ---- expand across the window ----
        for i in range(WINDOW_DAYS + 1):
            cand = day0 + timedelta(days=i)        # DEFAULT_TZ midnight
            cand_date = cand.date()

            matches_day = (days_idx and cand.weekday() in days_idx) or occurs_on(cand_date, rrule_dict)
            if not matches_day:
                continue

            start_iso, end_iso, local_date, local_time = build_iso(cand, t24, duration, tz)

            # Compare in DEFAULT_TZ to keep a consistent "now" window
            begin_default = datetime.fromisoformat(start_iso).astimezone(DEFAULT_TZ)
            if not (now_default <= begin_default <= window_end):
                continue

            nco, unassigned, _src = nco_for(net_id, local_date, rota_idx, overrides, vacations_idx)

            occurrences.append({
                "id": net_id,
                "name": name,
                "start_iso": start_iso,
                "end_iso": end_iso,
                "duration_min": duration,
                "local_date": local_date,
                "local_time": local_time,
                "location": location,
                "nco": nco,
                "unassigned": unassigned,
                "note": ""
            })

    occurrences.sort(key=lambda x: x["start_iso"])

    out = {
        "generated_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "tz": LOCAL_TZ_NAME,
        "items": occurrences
    }
    json.dump(out, sys.stdout, ensure_ascii=False)
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
