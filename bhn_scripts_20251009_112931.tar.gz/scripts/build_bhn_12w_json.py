#!/usr/bin/env python3
"""
Read _data/bhn_ncos_schedule.yml (BHN-only, 12 dates) and _data/ncos.yml (time/tz/duration),
emit bhn_nco_12w.json for the BHN NCO page.
Env via /opt/bhn/bhn.env: BHN_REPO_ROOT
"""
from __future__ import annotations
import os, sys, json
from pathlib import Path
from datetime import datetime, timedelta, UTC, time as dtime
from zoneinfo import ZoneInfo

try:
    import yaml
except Exception as e:
    sys.stderr.write(f"[error] PyYAML not installed: {e}\n")
    sys.exit(2)

REPO_ROOT = Path(os.environ.get("BHN_REPO_ROOT", str(Path.home())))
DATA = REPO_ROOT / "_data"
SCHED = DATA / "bhn_ncos_schedule.yml"
NCOS  = DATA / "ncos.yml"

def load_yaml(p: Path):
    if not p.exists():
        raise FileNotFoundError(f"Missing input YAML: {p}")
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def parse_hhmm(s: str) -> dtime:
    try:
        h,m = s.strip().split(":"); return dtime(int(h), int(m))
    except Exception:
        return dtime(10,0)

def main() -> int:
    sched = load_yaml(SCHED)        # {"items":[{"date","nco","notes","unassigned"}, ...]}
    meta  = load_yaml(NCOS)         # has: time_zone, start_local, duration_min, location

    tzname = meta.get("time_zone", "America/New_York")
    tz = ZoneInfo(tzname)
    start_local = parse_hhmm(meta.get("start_local","10:00"))
    duration_min = int(meta.get("duration_min", 60))
    location = meta.get("location", "AllStar 50631 · DMR TG 31672 · Echolink *KV3T-L")

    out_items = []
    for row in (sched.get("items") or []):
        date_str = str(row.get("date") or "").strip()
        if not date_str:
            continue
        nco = str(row.get("nco") or "").strip().upper()
        unassigned = bool(row.get("unassigned", False))
        note = str(row.get("notes") or "").strip()

        try:
            y, m, d = [int(x) for x in date_str.split("-")]
            start_dt = datetime(y, m, d, start_local.hour, start_local.minute, tzinfo=tz)
            end_dt = start_dt + timedelta(minutes=duration_min)
            start_iso = start_dt.isoformat()
            end_iso = end_dt.isoformat()
            local_date = start_dt.strftime("%Y-%m-%d")
            local_time = start_dt.strftime("%H:%M")
        except Exception:
            start_iso = end_iso = ""
            local_date = date_str
            local_time = f"{start_local.hour:02d}:{start_local.minute:02d}"

        out_items.append({
            "id": "bhn-main",
            "name": "Blind Hams Digital Net",
            "start_iso": start_iso,
            "end_iso": end_iso,
            "duration_min": duration_min,
            "local_date": local_date,
            "local_time": local_time,
            "location": location,
            "nco": nco,
            "unassigned": unassigned,
            "note": note
        })

    out = {
        "generated_at": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "tz": tzname,
        "items": out_items
    }
    json.dump(out, sys.stdout, ensure_ascii=False)
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as e:
        sys.stderr.write(f"ERROR: {e}\n")
        sys.exit(1)
PY
sudo chmod 755 /opt/bhn/scripts/build_bhn_12w_json.py
