# Blind Hams Digital Net — Website Repo

This is the public repository for the Blind Hams Digital Net homepage and related site content.

Questions or suggestions?
- Send a GitHub commit/PR, or
- Email: k5ner@email.cc

Thanks for helping make the Blind Hams Digital Net better for everyone.
