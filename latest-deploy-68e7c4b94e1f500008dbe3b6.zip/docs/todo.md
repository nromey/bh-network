# Project TODOs

## Accessibility Enhancements
- [ ] Add keyboard shortcuts for switching between table and headings views on nets pages.

